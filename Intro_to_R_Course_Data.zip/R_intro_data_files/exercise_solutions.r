#=============
# Exercise 4
#=============

# set the working directory - wherever the data files are
setwd("D:/courses/Introduction_to_R/R_intro_data_files/")

# import file
child.var <- read.csv("Child_Variants.csv")

# check it looks ok
head(child.var)

# display row 11
child.var[11,]

# mean of MutantReadPercent column
mean(child.var$MutantReadPercent)


#=====================
# Exercise 5a example
#=====================
all.data <- read.delim("small_file.txt")

# filtering by length
all.data$Length < 60

all.data[all.data$Length < 60, ] # has not altered the data structure

filt.short <- all.data[all.data$Length < 60, ]

# filtering by category
filt.short$Category == "A"

filt.short[filt.short$Category == "A", ]

filt.short.catA <- filt.short[filt.short$Category == "A", ]

# all in one go
filt.short.catA.again <- all.data[(all.data$Length < 60) & (all.data$Category == "A"), ]



#=============
# Exercise 5b
#=============

# filter child variant dataset for rows where MutantReadPercent >= 70
high.mutant.read.percent <- child.var[child.var$MutantReadPercent >= 70,]

# filter again for rows where REF column == C
refC <- high.mutant.read.percent[high.mutant.read.percent$REF == "C",]

# calculate the number of rows in refC where ALT = T, G and A
altT <- sum(refC$ALT == "T")
altG <- sum(refC$ALT == "G")
altA <- sum(refC$ALT == "A")

# combine the 3 values into a vector - required for the next exercise
mutation.counts <- c(altT, altG, altA)




#=============
# Exercise 6
#=============  
  
# histogram
hist(child.var$MutantReadPercent)

# increase number of breaks
hist(child.var$MutantReadPercent, breaks=50)

# boxplot
# this works
boxplot(child.var$MutantReadPercent, high.mutant.read.percent$MutantReadPercent)
# better practice
boxplot(list(child.var$MutantReadPercent, high.mutant.read.percent$MutantReadPercent))

# barplot
barplot(mutation.counts, names.arg=c("T","G","A"), col=rainbow(3))



#=============
# Exercise 7
#=============

# import neutrophils file
neut <- read.csv("neutrophils.csv")
# boxplot
boxplot(neut, main="neutrophils dataset")
# calculate column means
colMeans(neut, na.rm=T)
# barplot
barplot(colMeans(neut, na.rm=T))

# import brain bodyweight file
bb <- read.delim("brain_bodyweight.txt", row.names=1)
#log transform the data
bb.log <- log2(bb)
# create scatterplot
plot(bb.log)
# change some plotting parameters
plot(bb.log, col="blue", pch=16, xlab="log2 body weight (kg)", ylab="log2 brain weight (g)", main= "brain and bodyweight of a range of animals")

# import chr data file
chr.data <- read.delim("chr_data.txt")
# remove the first column
chr.data <- chr.data[,-1] # or chr.data <- chr.data[,2:4]
# plot one column of data as a line graph
plot(x=chr.data[,1], y=chr.data[,2], type="l")




